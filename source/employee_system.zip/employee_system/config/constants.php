<?php
define('BASE_URL', '/laptrinhweb_da19_hk2_2425/source/employee_system/');
?>