
<?php
include_once 'config/auth_check.php';
include_once 'config/constants.php';
include_once __DIR__ . '/views/layout/header.php';
require_once 'controllers/CustomerController.php';
include_once __DIR__ . '/views/layout/footer.php';
?>
