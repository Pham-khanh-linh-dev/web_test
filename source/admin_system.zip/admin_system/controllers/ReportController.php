<?php
require_once __DIR__ . '/../models/Report.php';

class ReportController
{
    public function index()
    {
      
        include __DIR__ . '/../views/report/index.php';
        $fromDate = $_GET['from_date'] ?? date('Y-m-d', strtotime('-6 days'));
        $toDate   = $_GET['to_date'] ?? date('Y-m-d');

        $report = new Report();

        $summary = $report->getSummary($fromDate, $toDate);
        $summary = fillEmptyDates($summary, $fromDate, $toDate);
        $orders  = $report->getOrders($fromDate, $toDate);

        include __DIR__ . '/../views/report/index.php';
    }

    public function detail()
    {
        $orderId = $_GET['id'] ?? null;
        if (!$orderId) {
            die('Thiếu ID đơn hàng');
        }
        $report = new Report();
        $orderItems = $report->getOrderDetail($orderId);

        include __DIR__ . '/../views/report/detail.php';
    }
}
function fillEmptyDates($summary, $fromDate, $toDate)
{
    $map = [];
    foreach ($summary as $item) {
        $map[$item['day']] = $item;
    }

    $from = new DateTime($fromDate);
    $to = new DateTime($toDate);
    $filled = [];

    while ($from <= $to) {
        $day = $from->format('Y-m-d');
        $filled[] = $map[$day] ?? [
            'day' => $day,
            'total_orders' => 0,
            'total_products' => 0,
            'total_revenue' => 0,
            'total_profit' => 0,
        ];
        $from->modify('+1 day');
    }

    return $filled;
}
